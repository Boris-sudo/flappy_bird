import pygame as pg


class Player(pg.sprite.Sprite):
    def __init__(self, x, y, file):
        pg.sprite.Sprite.__init__(self)
        # image
        self.image = file.convert_alpha()
        self.image_width = self.image.get_width()
        self.image_height = self.image.get_height()
