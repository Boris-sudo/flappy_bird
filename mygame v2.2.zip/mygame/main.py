import random

import cv2
import mediapipe as mp
import numpy as np
import pygame

import colon
import ground
import player
from cursor import *
from functional import *


# ///////////////////////// Цвета

# ///////////////////////// Основные переменные
FPS = 50
WIDTH = 640
HEIGHT = 480
# ///////////////////////// Escape buttons
RECT_BUTTON_WIDTH = 500
RECT_BUTTON_HEIGHT = 80
RECT_BUTTON_BORDER_WIDTH = 10
ESCAPE_BUTTON_COLOR = (243, 239, 224)
# ///////////////////////// Детекторы
handsDetector = mp.solutions.hands.Hands(
    min_detection_confidence=0.9,
    max_num_hands=1
)  # создаем детектор рук
cap = cv2.VideoCapture(0)  # Включим камеру
cap.set(3, 1000)
cap.set(4, 1000)
# ///////////////////////// Создадим экран и таймер
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
# ///////////////////////// Пути к картинкам
BIRD_IMAGE_LIST = [
    pg.image.load('sprites/bird1.png'),
    pg.image.load('sprites/bird2.png'),
    pg.image.load('sprites/bird3.png'),
]
bird_sprite = BIRD_IMAGE_LIST[0]
GROUND = 'sprites/base.png'
PIPE = 'sprites/pipe.png'
button1 = StartButton("Start", WIDTH, 150, screen)
button2 = StartButton("Shop", WIDTH, 300, screen)
escape_from_shop_button = pygame.Rect(WIDTH-35, 0, 30, 30)
background = pygame.image.load('sprites/background.png')
# ///////////////////////// Замок
lock_sp = pygame.image.load('sprites/lock.png').convert_alpha()
lock_sp = pygame.transform.scale(lock_sp, (40, 40))
# ///////////////////////// Курсор
click_timer = 0
last_button = ""
EPS = 30
cursor_sp = pygame.image.load('sprites/cursor.png')
cursor_sp = pygame.transform.scale(cursor_sp, (30, 30))
cursor = Cursor(cursor_sp)
# ///////////////////////// Score
game_score = 0
high_score = 0
high_score_text = Text(screen, "Record: ", (10, 10))
game_score_text = Text(screen, "Score: ", (10, 30))
# ///////////////////////// Скины на птиц
birds_rect_list = []
min_score = [0, 50, 60]
index_chosen_bird_sprite = 0
x, y = 100, 100
length_bird = 85
height_bird = 60
for i in range(len(BIRD_IMAGE_LIST)):
    img = pygame.transform.scale(BIRD_IMAGE_LIST[i], (length_bird, height_bird))
    image_rect = img.get_rect(topleft=(x, y))
    birds_rect_list.append(image_rect)
    x += 150


running = True
game_mode = 0
# game_mode:
# 0 - menu mod
# 1 - play mode
# 2 - shop
# TODO управление пальцами полностью


while running:
    screen.fill((34, 163, 159))
    if game_mode == 0:
        while game_mode == 0:
            screen.fill((34, 163, 159))
            ret, img = cap.read()
            pos = (-100, -100)
            if cv2.waitKey(1) & 0xFF == ord('q') or not ret:
                break
            img = np.fliplr(img)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            results = handsDetector.process(img)
            if results.multi_hand_landmarks is not None and results.multi_handedness[0].classification[0].score >= 0.9:
                player_y = int(results.multi_hand_landmarks[0].landmark[8].y * img.shape[0])
                player_x = int(results.multi_hand_landmarks[0].landmark[8].x * img.shape[1])
                pos = (player_x, player_y)
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            cv2.imshow("Hands", img)

            if button1.on_click(pos):
                click_timer += 1
                if click_timer == EPS:
                    game_mode = 1
            elif button2.on_click(pos):
                click_timer += 1
                if click_timer == EPS:
                    game_mode = 2
            else:
                click_timer = 0

            button1.on_hover(pos)
            button2.on_hover(pos)
            button1.draw(screen)
            button2.draw(screen)
            # рисовка текста
            high_score_text.draw_text(high_score)
            # рисовка курсора
            cursor_rect = cursor.image.get_rect(topleft=(pos[0], pos[1]))
            screen.blit(cursor.image, cursor_rect)
            # После отрисовки всего, переворачиваем экран
            pygame.display.flip()
            clock.tick(FPS)

    elif game_mode == 1:
        # Колонны
        down_colons_array = []  # Массив колонн снизу
        were_in_place = []  # массив прохода между колоннами
        up_colons_array = []  # Массив колонн сверху
        timer = 0  # Таймер появления колонн
        colon_spawn_delay = 50  # время между спавном колонн
        colon_speed = 8  # скорость колонн
        minimum = 140  # минимальная дыра между колоннами
        score = 0  # кол-во для изменения скорости игры
        limit_score = 10
        # Координаты птицы
        player_x = WIDTH / 2
        player_y = HEIGHT / 2
        bird = player.Player(player_x, player_y, bird_sprite)  # Создадим птицу
        dirt = ground.Ground(0, 0, GROUND)  # Создадим землю
        while game_mode == 1 and cap.isOpened():
            screen.fill((34, 163, 159))

            ret, img = cap.read()
            if cv2.waitKey(1) & 0xFF == ord('q') or not ret:
                game_mode = 0

            # скан камеры и нахождение местоположения пальца
            img = np.fliplr(img)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            results = handsDetector.process(img)
            if results.multi_hand_landmarks is not None and results.multi_handedness[0].classification[0].score >= 0.9:
                player_y = int(results.multi_hand_landmarks[0].landmark[8].y * img.shape[0])
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            cv2.imshow("Hands", img)

            # отрисовка
            background_rect = background.get_rect(topleft=(0, 0))
            background_rect2 = background.get_rect(topleft=(background.get_width(), 0))
            background_rect3 = background.get_rect(topleft=(2 * background.get_width(), 0))
            screen.blit(background, background_rect)
            screen.blit(background, background_rect2)
            screen.blit(background, background_rect3)
            # КОЛОННЫ
            if timer >= colon_spawn_delay:
                height_bottom = random.randint(10, 290 - minimum / 2)
                height_up = random.randint(10, HEIGHT - height_bottom - minimum / 2 - dirt.image_height)
                # колонна снизу
                pipe = pg.image.load(PIPE)
                colon_i_d = colon.Colon(WIDTH, HEIGHT - height_bottom - dirt.image_height, pipe)
                pipe = pg.transform.rotate(pipe, 180)
                colon_i_u = colon.Colon(WIDTH, - colon_i_d.image_height + height_up, pipe)
                were_in_place.append(True)
                down_colons_array.append(colon_i_d)
                up_colons_array.append(colon_i_u)
                timer = 0
            for c in down_colons_array:
                c.update(colon_speed)
                if c.x + c.image_width <= 0:
                    down_colons_array.remove(c)
                    were_in_place.remove(were_in_place[0])
                else:
                    colon_rect = c.image.get_rect(topleft=(c.x, c.y))
                    screen.blit(c.image, colon_rect)
            for c in up_colons_array:
                c.update(colon_speed)
                if c.x + c.image_width <= 0:
                    up_colons_array.remove(c)
                else:
                    colon_rect = c.image.get_rect(topleft=(c.x, c.y))
                    screen.blit(c.image, colon_rect)
            # ПТИЦА
            bird_rect = bird.image.get_rect(topleft=(player_x, player_y))
            screen.blit(bird.image, bird_rect)
            # Текст
            high_score_text.draw_text(high_score)
            game_score_text.draw_text(game_score)
            # ЗЕМЛЯ
            ground_rect = dirt.image.get_rect(topleft=(0, HEIGHT - dirt.image_height))
            screen.blit(dirt.image, ground_rect)
            ground_rect = dirt.image.get_rect(topleft=(dirt.image_width, HEIGHT - dirt.image_height))
            screen.blit(dirt.image, ground_rect)

            if player_x > WIDTH or player_x < 0 or player_y < 0 or player_y > HEIGHT - dirt.image_height - bird.image_height:
                game_mode = 0
                game_score = 0
            for i in range(len(down_colons_array)):
                c = down_colons_array[i]
                if c.rect.collidepoint((player_x, player_y)) \
                        or c.rect.collidepoint(player_x + bird.image_width, player_y) \
                        or c.rect.collidepoint(player_x, player_y + bird.image_height) \
                        or c.rect.collidepoint(player_x + bird.image_width, player_y + bird.image_height):
                    game_mode = 0
                    game_score = 0
                if c.rect.collidepoint((player_x, HEIGHT - dirt.image_height)) and were_in_place[i]:
                    score += 1
                    game_score += 1
                    high_score = max(high_score, game_score)
                    were_in_place[i] = False
            for c in up_colons_array:
                if c.rect.collidepoint((player_x, player_y)) \
                        or c.rect.collidepoint(player_x + bird.image_width, player_y) \
                        or c.rect.collidepoint(player_x, player_y + bird.image_height) \
                        or c.rect.collidepoint(player_x + bird.image_width, player_y + bird.image_height):
                    game_mode = 0
                    game_score = 0

            if score == limit_score:
                colon_spawn_delay = max(18, colon_spawn_delay - 10)
                if colon_spawn_delay == 18:
                    colon_speed = max(colon_speed + 1, 11)
                score = 0

            # рендеринг дисплея
            pygame.display.flip()
            timer += 1
            clock.tick(FPS)

    elif game_mode == 2:
        screen.fill((34, 163, 159))
        while game_mode == 2:
            screen.fill((34, 163, 159))
            ret, img = cap.read()
            pos = (-100, -100)
            if cv2.waitKey(1) & 0xFF == ord('q') or not ret:
                break
            img = np.fliplr(img)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            results = handsDetector.process(img)
            if results.multi_hand_landmarks is not None and results.multi_handedness[0].classification[0].score >= 0.9:
                player_y = int(results.multi_hand_landmarks[0].landmark[8].y * img.shape[0])
                player_x = int(results.multi_hand_landmarks[0].landmark[8].x * img.shape[1])
                pos = (player_x, player_y)
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            cv2.imshow("Hands", img)

            for i in range(len(birds_rect_list)):
                if birds_rect_list[i].collidepoint(pos) and high_score >= min_score[i]:
                    index_chosen_bird_sprite = i
                    bird_sprite = BIRD_IMAGE_LIST[i]
            if escape_from_shop_button.collidepoint(pos):
                game_mode = 0

            # рисовка спрайтов птиц
            for i in range(len(birds_rect_list)):
                screen.blit(pygame.transform.scale(BIRD_IMAGE_LIST[i], (85, 60)), birds_rect_list[i])
                if high_score < min_score[i]:
                    lock_rect = lock_sp.get_rect(center=birds_rect_list[i].center)
                    screen.blit(lock_sp, lock_rect)
            # рисовка текста
            high_score_text.draw_text(high_score)
            # рисовка курсора
            cursor_rect = cursor.image.get_rect(topleft=(pos[0], pos[1]))
            screen.blit(cursor.image, cursor_rect)
            # рисовка контура вокруг выбранной птицы
            for i in range(len(BIRD_IMAGE_LIST)):
                if index_chosen_bird_sprite == i:
                    rect = pygame.Rect(0, 0, length_bird, height_bird)
                    rect.center = birds_rect_list[i].center
                    pygame.draw.rect(screen, (34, 34, 34), rect, 2)
                else:
                    rect = pygame.Rect(0, 0, length_bird, height_bird)
                    rect.center = birds_rect_list[i].center
                    pygame.draw.rect(screen, (67, 66, 66), rect, 2)
            rect1 = pygame.draw.rect(screen, ESCAPE_BUTTON_COLOR, escape_from_shop_button, RECT_BUTTON_BORDER_WIDTH)
            #  После отрисовки всего, переворачиваем экран
            pygame.display.flip()
            clock.tick(FPS)

cv2.destroyAllWindows()
