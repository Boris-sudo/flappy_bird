import pygame as pg


class Cursor(pg.sprite.Sprite):
    def __init__(self, file):
        pg.sprite.Sprite.__init__(self)
        # image
        self.image = file.convert_alpha()
        self.image_width = self.image.get_width()
        self.image_height = self.image.get_height()

