import pygame as pygame
from math import *


class StartButton:
    font_name = "Arial"
    font_size = 30
    width = 500
    width_above = 510
    height = 90
    height_above = 100

    def __init__(self, t, WIDTH, margin_top, surface):
        pygame.init()
        self.surface = surface
        self.button_rect = pygame.Rect((WIDTH - self.width) / 2, margin_top, self.width, self.height)
        self.button_rect_above = pygame.Rect((WIDTH - self.width_above) / 2, margin_top - 5, self.width_above, self.height_above)
        self.WIDTH = WIDTH
        self.margin_top = margin_top
        self.where = self.button_rect.center
        self.color = (243, 239, 224)
        self.font = None
        self.text = t

    def on_click(self, pos):
        return self.button_rect.collidepoint(pos)

    def on_hover(self, pos):
        if self.button_rect.collidepoint(pos):
            self.color = (67, 66, 66)
        else:
            self.color = (243, 239, 224)

    def draw(self, surface):
        button_above = pygame.draw.rect(self.surface, pygame.Color(255, 255, 255, 127), self.button_rect_above, 20)
        button = pygame.draw.rect(self.surface, self.color, self.button_rect, 10)
        font = pygame.font.SysFont(self.font_name, self.font_size)
        text = font.render(self.text, True, self.color)
        text_rect = text.get_rect(center=self.where)
        surface.blit(text, text_rect)


def get_dis(a1, a2):
    return sqrt((a1[0] - a2[0]) * (a1[0] - a2[0]) + (a1[1] - a2[1]) * (a1[1]- a2[1]))


class Text:
    font_name = "Arial"
    font_size = 15
    font_color = (255, 255, 255)

    def __init__(self, surface, text, pos):
        pygame.init()
        self.surface = surface
        self.pos = pos
        self.text = text

    def draw_text(self, score):
        font = pygame.font.SysFont(self.font_name, self.font_size)
        text = font.render(self.text + str(score), True, self.font_color)
        text_rect = text.get_rect()
        text_rect.topleft = self.pos
        self.surface.blit(text, text_rect)
