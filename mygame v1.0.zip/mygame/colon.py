import pygame as pg


class Colon(pg.sprite.Sprite):
    def __init__(self, x, y, file):
        pg.sprite.Sprite.__init__(self)
        # image
        self.image = self.image = file.convert_alpha()
        self.image_width = self.image.get_width()
        self.image_height = self.image.get_height()
        # rect
        self.x = x
        self.y = y

    def update(self, speed):
        self.x -= speed
        self.rect = pg.Rect((self.x, self.y, self.image_width, self.image_height))
