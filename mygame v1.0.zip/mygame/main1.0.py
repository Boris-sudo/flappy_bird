import cv2
import mediapipe as mp
import numpy as np
import pygame as pg
import pygame.image

import colon
import ground
import player

GRAY = (225, 225, 225)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
RED = (232, 0, 0)

FPS = 100
WIDTH = 640
HEIGHT = 480
PLAYER = 'sprites/bird1.png'
GROUND = 'sprites/base.png'
PIPE = pygame.image.load('sprites/pipe.png')
PIPE_SPAWN_DELAY = 1
COLON_SPEED = 10
colons_array = []
timer = 0
player_x = WIDTH / 2
player_y = HEIGHT / 2

cap = cv2.VideoCapture(0)
screen = pg.display.set_mode((WIDTH, HEIGHT))
clock = pg.time.Clock()

# создаем детектор
handsDetector = mp.solutions.hands.Hands()
bird = player.Player(player_x, player_y, pygame.image.load(PLAYER))
ground = ground.Ground(0, 0, GROUND)

while cap.isOpened():
    screen.fill(BLACK)

    ret, img = cap.read()
    if cv2.waitKey(1) & 0xFF == ord('q') or not ret:
        break

    # скан камеры и нахождение местоположения пальца
    img = np.fliplr(img)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = handsDetector.process(img)
    if results.multi_hand_landmarks is not None:
        player_y = int(results.multi_hand_landmarks[0].landmark[8].y * img.shape[0])
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        cv2.imshow("Hands", img)

    # отрисовка
    # КОЛОННЫ
    if timer == FPS * PIPE_SPAWN_DELAY:
        # TODO сделать появление колонны с различной высотой и сверху
        colon_i = colon.Colon(WIDTH, HEIGHT, PIPE)
        colons_array.append(colon_i)
        timer = 0
    for c in colons_array:
        c.x -= COLON_SPEED
        if c.x <= 0:
            colons_array.remove(c)
        else:
            colon_rect = c.image.get_rect(topleft=(c.x, c.y))
            screen.blit(c.image, colon_rect)
    # ПТИЦА
    bird_rect = bird.image.get_rect(topleft=(player_x, player_y))
    screen.blit(bird.image, bird_rect)
    # ЗЕМЛЯ
    ground_rect = ground.image.get_rect(topleft=(0, HEIGHT-ground.image_height))
    screen.blit(ground.image, ground_rect)
    ground_rect = ground.image.get_rect(topleft=(ground.image_width, HEIGHT - ground.image_height))
    screen.blit(ground.image, ground_rect)

    if player_x > WIDTH or player_x < 0 or player_y < 0 or player_y > HEIGHT-ground.image_height-bird.image_height:
        break
    for c in colons_array:
        if c.rect.collidepoint((player_x, player_y)):
            break

    # рендеринг дисплея
    pg.display.flip()
    timer += 1
    clock.tick(FPS)

handsDetector.close()
